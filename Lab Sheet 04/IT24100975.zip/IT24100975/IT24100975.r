setwd("C:/Users/IT24100975/Desktop/IT24100975")

branch_data <- read.table("./Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)

str(branch_data)

boxplot(branch_data,main="Sales Plot",outline=TRUE,outpch=8,horizontal = TRUE)
summary(Advertising_X2)
quantile(Advertising_X2)

get.outliers <- function(data){
  q1 <- quantile(data)[2]
  q3 <- quantile(data)[4]
  iqr <- q3-q1
  
  ub<- q3+1.5*iqr
  lb<- q1-1.5*iqr
  
  print(paste("Upper bound =", ub))
  print(paste("Lower bound =", lb))
  print(paste("outliers =", paste(sort(data[data<lb | data>ub]),collapse=", ")))
}

get.outliers(Years_X3)





data1 <- read.table("Data1.txt",header=TRUE,sep=",")